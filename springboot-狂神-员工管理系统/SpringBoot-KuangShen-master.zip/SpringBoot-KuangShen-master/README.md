# SpringBoot-CRUD
SpringBoot整合CRUD实现员工管理案例

## 项目介绍
项目采用SpringBoot构建。前端使用Bootstrap框架开发，采用Thymeleaf模板引擎渲染页面数据。
没有配置与数据库的连接，方便测试。

## 运行环境
 JDK1.8

## 如何运行
 1.git clone 项目地址  
 2.用IDEA打开，运行SpringbootWebApplication
 
## 参考资料
[狂神说Java](https://www.bilibili.com/video/av75233634?p=20)

